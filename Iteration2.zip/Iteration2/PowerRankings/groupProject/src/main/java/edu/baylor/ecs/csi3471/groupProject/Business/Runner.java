package edu.baylor.ecs.csi3471.groupProject.Business;

import edu.baylor.ecs.csi3471.groupProject.UI.LoginPage;

public class Runner {
	public static User curUser;
	public static void main(String[] args) {
		LoginPage lp = new LoginPage();
	}
}
